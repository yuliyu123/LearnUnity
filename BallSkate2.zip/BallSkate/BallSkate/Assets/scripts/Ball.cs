﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    private Vector2 first = Vector2.zero;
    private Vector2 second = Vector2.zero;
    public float upForce;                   //Upward force of the "flap".
    public float downForce = -200;  
    private bool isDead = false;            //Has the player collided with a wall?

    private Rigidbody2D rb2d;               //Holds a reference to the Rigidbody2D component of the bird.
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("start");
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        // Debug.Log("update");
        if (isDead == false)
        {
            //Look for input to trigger a "flap".
            if (Input.GetMouseButtonDown(0))
            {
                first = new Vector2(Screen.width/2,Screen.height/2);
                second = Input.mousePosition;
                if (second.x > first.x)
                {
                    Debug.Log("left");
                }
                else
                {
                    Debug.Log("right");
                }
                Debug.Log("    " + Input.mousePosition);
                Debug.Log("Input.GetMouseButtonDown");
                //...zero out the birds current y velocity before...
                rb2d.velocity = Vector2.zero;
                // new Vector2(rb2d.velocity.x, 0);
                //..giving the bird some upward force.
                rb2d.AddForce(new Vector2(0, downForce));
                
            }
        }
    }
    
        
    void OnMouseTouch()
    {

        if(Event.current.type == EventType.MouseDown){//记录鼠标按下的位置
            first = Event.current.mousePosition;
}


        if(Event.current.type == EventType.MouseDrag){//记录鼠标拖动的位置
            second = Event.current.mousePosition;
            if(second.x < first.x)
            {
                Debug.Log("left");
            }


            if(second.x>first.x)
            {//拖动的位置的x坐标比按下的位置的x坐标大时,响应向右事件
                Debug.Log("right");
            }
        first = second;
    }


    }

    void OnTriggerEnter(Collider collider)  
    {
        Debug.Log("OnTriggerEnter");
    }

    void OnCollisionEnter(Collision collision)   
    {  
        //进入碰撞器执行的代码
        Debug.Log("OnCollisionEnter");
    }
}
